﻿using System;
using Stripe;
using Stripe_Payments_Web_Api.Application;
using Stripe_Payments_Web_Api.Contracts;

namespace Stripe_Payments_Web_Api
{
	public static class StripeInfrastructure
    {
		private static string? connectionString;
        public static string? ConnectionString {  get => connectionString; private set => connectionString = value; }

        public static IServiceCollection AddStripeInfrastructure(this IServiceCollection services, IConfiguration configuration)
		{
			StripeConfiguration.ApiKey = configuration.GetValue<string>("StripeSettings:SecretKey");

            connectionString = configuration.GetValue<string>("ConnectionStrings:DiplomAdvisorContext");

            return services
				.AddScoped<CustomerService>()
				.AddScoped<ChargeService>()
				.AddScoped<TokenService>()
                .AddScoped<SubscriptionService>()
                .AddScoped<IStripeAppService, StripeAppService>();
		}
	}
}

