﻿using System;
using System.Configuration;
using System.Reflection.Metadata;
using Stripe;
using Stripe_Payments_Web_Api.Contracts;
using Stripe_Payments_Web_Api.Models.Stripe;

using Stripe_Payments_Web_Api;

namespace Stripe_Payments_Web_Api.Application
{
	public class StripeAppService : IStripeAppService
	{
        private static string isCancelled = "Annuulé";

        private readonly ChargeService _chargeService;
        private readonly CustomerService _customerService;
        private readonly TokenService _tokenService;
        private readonly SubscriptionService _subscriptionService;
        /* private readonly InvoiceService _invoiceService; */

        public StripeAppService(
               ChargeService chargeService,
               CustomerService customerService,
               TokenService tokenService,
               SubscriptionService subscriptionService    
        )
        {
            _chargeService = chargeService;
            _customerService = customerService;
            _tokenService = tokenService;
            _subscriptionService = subscriptionService;
        }

        /// <summary>
        /// Create a new customer at Stripe through API using customer and card details from records.
        /// </summary>
        /// <param name="customer">Stripe Customer</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns>Stripe Customer</returns>
        public async Task<StripeCustomer?> AddStripeCustomerAsync(AddStripeCustomer customer, CancellationToken ct)
        {
            // Set Stripe Token options based on Customer data
            TokenCreateOptions tokenOptions = new TokenCreateOptions
            {
                Card = new TokenCardOptions
                {
                    Name = customer.Name,
                    Number = customer.CreditCard.CardNumber,
                    ExpYear = customer.CreditCard.ExpirationYear,
                    ExpMonth = customer.CreditCard.ExpirationMonth,
                    Cvc = customer.CreditCard.Cvc                  
                }
            };

            // Create new Stripe Token:
            Token stripeToken = await _tokenService.CreateAsync(tokenOptions, null, ct);

            // TODO  : integrate stripeToken.Card.Id (CardId) +  stripeToken.Id (TokenId) si nécessaire

            // Set Customer Options : Add City
            CustomerCreateOptions customerOptions = new CustomerCreateOptions();

            customerOptions.Name = customer.Name;
            customerOptions.Email = customer.Email;

            // DiplomAdvisor External Key = Id of AspUsers:
            Dictionary<string,string> customerMetaData = new Dictionary<string,string>();
            customerMetaData.Add("externalId", customer.DiplomAdvisorCompanyKey.ToString());
            customerOptions.Metadata = customerMetaData;
            string key = customerMetaData.Values.First();

            customerOptions.Source = stripeToken.Id;

            // City:
            AddressOptions addressOptions = new AddressOptions();
            addressOptions.City = customer.City;
            customerOptions.Address = addressOptions;

            try
            {
                // Create Customer at Stripe:
                Customer createdCustomer = await _customerService.CreateAsync(customerOptions, null, ct);

                // Log to Database:
                PeristenceStructure peristenceStructure = new PeristenceStructure();

                peristenceStructure.EventType = EventTypes.CustomerCreated;
                peristenceStructure.EventDate = DateTime.Now.ToString("yyyyMMddHHmmss");

                peristenceStructure.Name   = createdCustomer.Name;
                peristenceStructure.Email  = createdCustomer.Email;
                peristenceStructure.City   = createdCustomer.Address.City;
                peristenceStructure.KeyId    = key;
                peristenceStructure.CustomerId = createdCustomer.Id;

                PersistenceManager.CreateStripeEvent(peristenceStructure);

                // Return the created Customer at Stripe:
                return new StripeCustomer(createdCustomer.Name,
                                          createdCustomer.Email,
                                          createdCustomer.Address.City,
                                          key,
                                          createdCustomer.Id);
            }
            catch(Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Add a new payment at Stripe using Customer and Payment details.
        /// Customer has to exist at Stripe already.
        /// </summary>
        /// <param name="payment">Stripe Payment</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns><Stripe Payment/returns>
        public async Task<StripePayment?> AddStripePaymentAsync(AddStripePayment payment, CancellationToken ct)
        {
            // Set the options for the payment we would like to create at Stripe
            ChargeCreateOptions paymentOptions = new ChargeCreateOptions
            {
                Customer = payment.CustomerId,
                ReceiptEmail = payment.ReceiptEmail,
                Description = payment.Description,
                Currency = payment.Currency,
                Amount = payment.Amount
            };

            // Create Meta-Data:
            // DiplomAdvisor External Key = Id of AspUsers
            Dictionary<string, string> paymenMetaData = new Dictionary<string, string>();
            paymenMetaData.Add("externalId", payment.DiplomAdvisorCompanyKey.ToString());
            paymentOptions.Metadata = paymenMetaData;
            string key = paymenMetaData.Values.First();

            try
            {
                // Create the payment
                var createdPayment = await _chargeService.CreateAsync(paymentOptions, null, ct);

                // Log to Database:
                PeristenceStructure peristenceStructure = new PeristenceStructure();

                peristenceStructure.EventType = EventTypes.PaymentOneShot;
                peristenceStructure.EventDate = DateTime.Now.ToString("yyyyMMddHHmmss");

                peristenceStructure.CustomerId = createdPayment.CustomerId;
                peristenceStructure.ReceiptEmail = createdPayment.ReceiptEmail;
                peristenceStructure.Description = createdPayment.Description;
                peristenceStructure.KeyId = key;
                peristenceStructure.Currency = createdPayment.Currency;
                peristenceStructure.Amount = createdPayment.Amount;
                peristenceStructure.PaymentId = createdPayment.Id;

                PersistenceManager.CreateStripeEvent(peristenceStructure);

                // Return the payment to requesting method
                return new StripePayment(
                  createdPayment.CustomerId,
                  createdPayment.ReceiptEmail,
                  createdPayment.Description,
                  createdPayment.Currency,
                  createdPayment.Amount,
                  key,
                  createdPayment.Id);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Add a new Subscription at Stripe using Customer details.
        /// Customer has to exist at Stripe already.
        /// </summary>
        /// <param name="subscription">Stripe Subscription</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns><Stripe Subscription/returns>
        public async Task<StripeSubscription> AddStripeSubscriptionAsync(AddStripeSubscription subscription, CancellationToken ct)
        {
            // Subscription Options:
            var options = new SubscriptionCreateOptions
            {
                Customer = subscription.CustomerId,
                Items = new List<SubscriptionItemOptions>
                    {
                        new SubscriptionItemOptions
                        {
                          Price = subscription.PriceId ,
                        },
                    },
            };

            var service = new SubscriptionService();
            service.Create(options);            

            // Set the options for the payment we would like to create at Stripe:
            ChargeCreateOptions paymentOptions = new ChargeCreateOptions
            {                
                Customer = subscription.CustomerId,
                ReceiptEmail = subscription.ReceiptEmail,
                Description = subscription.Description
            };

            // Create Meta-Data:
            // DiplomAdvisor External Key = Id of AspUsers
            Dictionary<string, string> paymenMetaData = new Dictionary<string, string>();
            paymenMetaData.Add("externalId", subscription.DiplomAdvisorCompanyKey.ToString());
            paymentOptions.Metadata = paymenMetaData;
            string key = paymenMetaData.Values.First();

            // Create a Payment Optionally
            //var createdSubscription = await _chargeService.CreateAsync(paymentOptions, null, ct);

            try
            {
                var createdSubscription = await _subscriptionService.CreateAsync(options, null, ct);

                // Log to Database:
                PeristenceStructure peristenceStructure = new PeristenceStructure();

                peristenceStructure.EventType = EventTypes.SubscriptionTaken;
                peristenceStructure.EventDate = DateTime.Now.ToString("yyyyMMddHHmmss");

                peristenceStructure.CustomerId = createdSubscription.CustomerId;
                peristenceStructure.PriceId = subscription.PriceId;
                peristenceStructure.Description = paymentOptions.Description;
                peristenceStructure.KeyId = key;
                peristenceStructure.ReceiptEmail = subscription.ReceiptEmail;
                peristenceStructure.SubscriptionId = createdSubscription.Id;

                PersistenceManager.CreateStripeEvent(peristenceStructure);

                // Return the New Subscription to requesting method
                return new StripeSubscription(
                  createdSubscription.CustomerId,
                  subscription.PriceId,
                  subscription.ReceiptEmail,
                  paymentOptions.Description,
                  key,
                  createdSubscription.Id);
            }
            catch (Exception) 
            {
                return (StripeSubscription)null;
            }
        }

        /// <summary>
        /// Delete a Subscription at Stripe using SubscriptionId.
        /// </summary>
        /// <param name="subscription">Stripe Subscription Id</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns><Stripe Subscription/returns>
        public async Task<bool> CancelStripeSubscriptionAsync(String subscriptionId, CancellationToken ct)
        {
            var service = new SubscriptionService();

            var cancelOptions = new SubscriptionCancelOptions
            {         
                InvoiceNow = true,
                Prorate = true,
            };

            // StripeEvents Structure:
            PeristenceStructure peristenceStructure = new PeristenceStructure();

            try
            {
                Subscription subscription = await service.CancelAsync(subscriptionId, cancelOptions);

                peristenceStructure.EventType = EventTypes.SubscriptionCancelled;
                peristenceStructure.EventDate = DateTime.Now.ToString("yyyyMMddHHmmss");

                if (subscriptionId == subscription.Id)
                {
                    peristenceStructure.SubscriptionId = isCancelled;                         // Set this Current SubscriptionId to Constant string 
                    peristenceStructure.Description = subscriptionId + ":" + "Cancellation";  // Describe the Removed SubscriptionId                    
                }

                PersistenceManager.ModifyStripeEvent(peristenceStructure, subscriptionId);
                return true;

            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Delete a Subscription at Stripe using SubscriptionId.
        /// </summary>
        /// <param name="stripeEventsId">a generic Id ( any Id Field )</param>
        /// <param name="ct">Cancellation Token</param>
        /// <returns><Stripe PeristenceStructure/returns>
        public async Task<List<PeristenceStructure?>> GetStripeEventByIdAsync(String stripeEventsId, String stripeEventsValue, CancellationToken ct)
        {
            List<PeristenceStructure?> peristenceStructure = new List<PeristenceStructure?>();

            try
            {
                peristenceStructure = (List<PeristenceStructure?>)PersistenceManager.getStripeEvent(stripeEventsId, stripeEventsValue);

                return peristenceStructure;
            }
            catch (Exception)
            {
                return peristenceStructure;
            }
        }

    }
}

