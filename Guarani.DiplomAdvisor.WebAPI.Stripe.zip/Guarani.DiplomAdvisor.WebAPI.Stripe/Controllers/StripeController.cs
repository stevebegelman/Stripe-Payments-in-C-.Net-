﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Stripe_Payments_Web_Api.Application;
using Stripe_Payments_Web_Api.Contracts;
using Stripe_Payments_Web_Api.Models.Stripe;

namespace Stripe_Payments_Web_Api.Controllers
{
    [Route("api/[controller]")]
    public class StripeController : Controller
    {
        private readonly IStripeAppService _stripeService;

        public StripeController(IStripeAppService stripeService)
        {
            _stripeService = stripeService;
        }

        [HttpPost("customer/add")]
        public async Task<ActionResult<StripeCustomer>> AddStripeCustomer([FromBody] AddStripeCustomer customer, CancellationToken ct)
        {
            try
            {
                StripeCustomer createdCustomer = await _stripeService.AddStripeCustomerAsync(customer, ct);
                return StatusCode(StatusCodes.Status200OK, createdCustomer);
            }
            catch (Exception ex) {
                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }
        }
       
        [HttpPost("events/bykeyvalue")]
        public async Task<ActionResult<List<PeristenceStructure?>>> GetStripeEventByIdAsync(string Id, string Value, CancellationToken ct)
        {
            try
            {
                List<PeristenceStructure?> customerEvent = (List<PeristenceStructure?>)await _stripeService.GetStripeEventByIdAsync(Id, Value, ct);

                return StatusCode(StatusCodes.Status200OK, customerEvent);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }
        }

        [HttpPost("payment/add")]
        public async Task<ActionResult<StripePayment>> AddStripePayment( [FromBody] AddStripePayment payment, CancellationToken ct)
        {
            try
            {
                StripePayment createdPayment = await _stripeService.AddStripePaymentAsync(payment, ct);

                return StatusCode(StatusCodes.Status200OK, createdPayment);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }
        }

        [HttpPost("subscription/add")]
        public async Task<ActionResult<StripeSubscription>> AddStripeSubscription( [FromBody] AddStripeSubscription subscription, CancellationToken ct)
        {
            try
            {
                StripeSubscription createdSubscription = await _stripeService.AddStripeSubscriptionAsync(subscription, ct);

                return StatusCode(StatusCodes.Status200OK, createdSubscription);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }
        }

        [HttpPost("subscription/cancel")]
        public async Task<ActionResult<bool>> CancelStripeSubscription(string subscriptionId, CancellationToken ct)
        {
            try
            {
                bool cancelSubscription = await _stripeService.CancelStripeSubscriptionAsync(subscriptionId, ct);

                if (cancelSubscription) return StatusCode(StatusCodes.Status200OK, subscriptionId);                              // Valid Suppression
                if (!cancelSubscription) return StatusCode(StatusCodes.Status404NotFound, subscriptionId + " " + "Not Found ");  // Invalid Cancellation
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }
            return false;
        }

        // =================================================================================================
        // Testing Only: No Implementation
        [HttpPost("paymentdeferred/add")]
        public async Task<ActionResult<StripePayment>> AddStripePaymentDeferred(
            [FromBody] AddStripePayment payment,
            CancellationToken ct)
        {
            try
            {
                //StripePayment createdPayment = await _stripeService.AddStripePaymentAsync(
                //payment,
                //ct);

                return StatusCode(StatusCodes.Status200OK, "Not Yet Implemented");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }
        }
    }
}

