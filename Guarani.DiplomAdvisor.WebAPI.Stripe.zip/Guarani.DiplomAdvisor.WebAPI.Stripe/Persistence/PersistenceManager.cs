﻿using Stripe;
using Stripe.Terminal;
using Stripe_Payments_Web_Api.Application;
using System;
using System.Data;
using Microsoft.Data.SqlClient;   // New Client Net Core
using System.Xml.Linq;
using Stripe_Payments_Web_Api.Controllers;

namespace Stripe_Payments_Web_Api.Application
{
    public enum EventTypes
    {
        CustomerCreated = 0,
        PaymentOneShot = 1,
        SubscriptionTaken = 2,
        SubscriptionCancelled = 3,
        Other = 4
    }

    // Shared By : All Event 'EventTypes'
    // ----------------------------------
    public struct PeristenceStructure
    {
        // Identity Key "Id" is Implicit in Table : 'StripeEvents.Id'
        private EventTypes eventType;
        private string name;
        private string city;
        private string email;
        private string keyId;
        private string customerId;
        private string receiptEmail;
        private string description;
        private string currency;
        private long amount;
        private string paymentId;
        private string priceId;
        private string subscriptionId;
        private string eventDate;

        public EventTypes EventType { get => eventType; set => eventType = value; }
        public string Name { get => name; set => name = value; }
        public string City { get => city; set => city = value; }
        public string Email { get => email; set => email = value; }
        public string KeyId { get => keyId; set => keyId = value; }
        public string CustomerId { get => customerId; set => customerId = value; }
        public string ReceiptEmail { get => receiptEmail; set => receiptEmail = value; }
        public string Description { get => description; set => description = value; }
        public string Currency { get => currency; set => currency = value; }
        public long Amount { get => amount; set => amount = value; }
        public string PaymentId { get => paymentId; set => paymentId = value; }
        public string PriceId { get => priceId; set => priceId = value; }
        public string SubscriptionId { get => subscriptionId; set => subscriptionId = value; }
        public string EventDate { get => eventDate; set => eventDate = value; }
    }

    public static class PersistenceManager
    {
        // Parameter Helper (Extension Method)
        public static SqlParameter AddWithNullableValue(this SqlParameterCollection collection, string parameterName, object value)
        {
            if (value == null)
                return collection.AddWithValue(parameterName, DBNull.Value);
            else
                return collection.AddWithValue(parameterName, value);
        }

        public static void CreateStripeEvent(PeristenceStructure peristenceStructure)
        {
            using (SqlConnection con = new SqlConnection(StripeInfrastructure.ConnectionString))
            {
                string query = " INSERT INTO StripeEvents (EventType,Name,City,Email,KeyId,CustomerId,ReceiptEmail, " +
                               " Description,Currency,Amount,PaymentId,PriceId,SubscriptionId,EventDate ) " +
                                      " VALUES(@EventType,@Name,@City,@Email,@KeyId,@CustomerId,@ReceiptEmail," +
                                             " @Description,@Currency,@Amount,@PaymentId,@PriceId,@SubscriptionId,@EventDate )";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithNullableValue("@EventType", peristenceStructure.EventType.ToString());
                        cmd.Parameters.AddWithNullableValue("@Name", peristenceStructure.Name);
                        cmd.Parameters.AddWithNullableValue("@City", peristenceStructure.City);
                        cmd.Parameters.AddWithNullableValue("@Email", peristenceStructure.Email);
                        cmd.Parameters.AddWithNullableValue("@KeyId", peristenceStructure.KeyId);
                        cmd.Parameters.AddWithNullableValue("@CustomerId", peristenceStructure.CustomerId);
                        cmd.Parameters.AddWithNullableValue("@ReceiptEmail", peristenceStructure.ReceiptEmail);
                        cmd.Parameters.AddWithNullableValue("@Description", peristenceStructure.Description);
                        cmd.Parameters.AddWithNullableValue("@Currency", peristenceStructure.Currency);
                        cmd.Parameters.AddWithNullableValue("@Amount", peristenceStructure.Amount);
                        cmd.Parameters.AddWithNullableValue("@PaymentId", peristenceStructure.PaymentId);
                        cmd.Parameters.AddWithNullableValue("@PriceId", peristenceStructure.PriceId);
                        cmd.Parameters.AddWithNullableValue("@SubscriptionId", peristenceStructure.SubscriptionId);
                        cmd.Parameters.AddWithNullableValue("@EventDate", peristenceStructure.EventDate);

                        string executableText = cmd.CommandText;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception)
                    {
                        con.Close();
                        cmd.Dispose();

                        return;
                    }
                }
            }
        }

        public static void ModifyStripeEvent(PeristenceStructure peristenceStructure, String subscriptionIdParam)
        {
            using (SqlConnection con = new SqlConnection(StripeInfrastructure.ConnectionString))
            {
                string query = " UPDATE StripeEvents " +
                                    " set EventType=@EventType,EventDate=@EventDate,SubscriptionId=@SubscriptionId,Description=@Description " +
                                        " WHERE SubscriptionId = @subscriptionIdParam ;";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithNullableValue("@subscriptionIdParam", subscriptionIdParam);

                        // On peut supprimer les élements qui ne servent pas; ils restent dans le cas ou la
                        // signature de la méthode est étendue
                        cmd.Parameters.AddWithNullableValue("@EventType", peristenceStructure.EventType.ToString());
                        cmd.Parameters.AddWithNullableValue("@Name", peristenceStructure.Name);
                        cmd.Parameters.AddWithNullableValue("@City", peristenceStructure.City);
                        cmd.Parameters.AddWithNullableValue("@Email", peristenceStructure.Email);
                        cmd.Parameters.AddWithNullableValue("@KeyId", peristenceStructure.KeyId);
                        cmd.Parameters.AddWithNullableValue("@CustomerId", peristenceStructure.CustomerId);
                        cmd.Parameters.AddWithNullableValue("@ReceiptEmail", peristenceStructure.ReceiptEmail);
                        cmd.Parameters.AddWithNullableValue("@Description", peristenceStructure.Description);
                        cmd.Parameters.AddWithNullableValue("@Currency", peristenceStructure.Currency);
                        cmd.Parameters.AddWithNullableValue("@Amount", peristenceStructure.Amount);
                        cmd.Parameters.AddWithNullableValue("@PaymentId", peristenceStructure.PaymentId);
                        cmd.Parameters.AddWithNullableValue("@PriceId", peristenceStructure.PriceId);
                        cmd.Parameters.AddWithNullableValue("@SubscriptionId", peristenceStructure.SubscriptionId);
                        cmd.Parameters.AddWithNullableValue("@EventDate", peristenceStructure.EventDate);

                        string executableText = cmd.CommandText.ToString();

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception)
                    {
                        con.Close();
                        cmd.Dispose();

                        return;
                    }
                }
            }
        }

        public static List<PeristenceStructure?> getStripeEvent(String IdParam, String IdValue)
        {            
            using (SqlConnection con = new SqlConnection(StripeInfrastructure.ConnectionString))
            {
                List<PeristenceStructure?> peristenceStructureList = new List<PeristenceStructure?>();

                using (SqlCommand cmd = new SqlCommand())
                {
                    con.Open();

                    string whereClause = "";

                    if (IdParam == "KeyId") { whereClause = " WHERE KeyId = @Value "; };
                    if (IdParam == "CustomerId") { whereClause = " WHERE  CustomerId = @Value "; };
                    if (IdParam == "PaymentId") { whereClause = " WHERE  PatmentId = @Value "; };
                    if (IdParam == "PriceId") { whereClause = " WHERE  PriceId = @Value "; };
                    if (IdParam == "SubscriptionId") { whereClause = " WHERE SubscriptionId = @Value "; };

                    string query = " SELECT EventType,Name,City,Email,KeyId,CustomerId,ReceiptEmail,Description," +
                                           "Currency,Amount,PaymentId,PriceId,SubscriptionId,EventDate from StripeEvents " + whereClause + ";";
                    cmd.Connection = con;

                    cmd.Parameters.AddWithNullableValue("@Value", IdValue );


                    try
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = query;

                        SqlDataReader readIn = cmd.ExecuteReader();

                        while (readIn.Read())
                        {
                            PeristenceStructure  peristenceStructure= new PeristenceStructure();

                            string myEventTypes = readIn[0].ToString();

                            if (myEventTypes == "CustomerCreated") peristenceStructure.EventType = EventTypes.CustomerCreated;
                            if (myEventTypes == "PaymentOneShot") peristenceStructure.EventType = EventTypes.PaymentOneShot;
                            if (myEventTypes == "SubscriptionTaken") peristenceStructure.EventType = EventTypes.SubscriptionTaken;
                            if (myEventTypes == "SubscriptionCancelled") peristenceStructure.EventType = EventTypes.SubscriptionCancelled;
                            if (myEventTypes == "Other") peristenceStructure.EventType = EventTypes.Other;

                            peristenceStructure.Name = readIn[1].ToString();
                            peristenceStructure.City = readIn[2].ToString();
                            peristenceStructure.Email = readIn[3].ToString();
                            peristenceStructure.KeyId = readIn[4].ToString();
                            peristenceStructure.CustomerId = readIn[5].ToString();
                            peristenceStructure.ReceiptEmail = readIn[6].ToString();
                            peristenceStructure.Description = readIn[7].ToString();
                            peristenceStructure.Currency = readIn[8].ToString();
                            peristenceStructure.Amount = (long)readIn[9];
                            peristenceStructure.PaymentId = readIn[10].ToString();
                            peristenceStructure.PriceId = readIn[11].ToString();
                            peristenceStructure.SubscriptionId = readIn[12].ToString();
                            peristenceStructure.EventDate = readIn[13].ToString();

                            peristenceStructureList.Add(peristenceStructure);

                        }
                        readIn.Close();
                        con.Close();

                        return peristenceStructureList;

                    }
                    catch (Exception e)
                    {
                        con.Close();
                        cmd.Dispose();

                        return null;
                    }
                }
            }
        }
    }
}



//SET ANSI_NULLS ON
//GO
//SET QUOTED_IDENTIFIER ON
//GO
//CREATE TABLE [StripeEvents] (
//  [Id][int] IDENTITY(1, 1) NOT NULL,
//  [EventType] [nvarchar] (32) NOT NULL,
//  [Name] [nvarchar] (24) NULL,
//	[City][nvarchar] (24) NULL,
//	[Email][nvarchar] (32) NULL,
//	[KeyId][nvarchar] (12) NULL,
//	[CustomerId][nvarchar] (32) NULL,
//	[ReceiptEmail][nvarchar] (32) NULL,
//	[Description][nvarchar] (64) NULL,
//	[Currency][nvarchar] (3) NULL,
//	[Amount][bigint] NULL,
//	[PaymentId][nvarchar] (32) NULL,
//	[PriceId][nvarchar] (32) NULL,
//	[SubscriptionId][nvarchar] (32) NULL,
//	[EventDate][nvarchar] (18) NULL
//) ON[PRIMARY]
//GO
//SET ANSI_PADDING ON
//GO
///****** Object:  Index [CustomerId_index]    Script Date: 23/01/2023 14:38:12 ******/
//CREATE NONCLUSTERED INDEX [CustomerId_index] ON[StripeEvents]
//(

//    [CustomerId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
//GO
//SET ANSI_PADDING ON
//GO
///****** Object:  Index [KeyId_index]    Script Date: 23/01/2023 14:38:13 ******/
//CREATE NONCLUSTERED INDEX [KeyId_index] ON[StripeEvents]
//(

//    [KeyId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
//GO
//SET ANSI_PADDING ON
//GO
///****** Object:  Index [PaymentId_index]    Script Date: 23/01/2023 14:38:13 ******/
//CREATE NONCLUSTERED INDEX [PaymentId_index] ON[StripeEvents]
//(

//    [PaymentId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
//GO
//SET ANSI_PADDING ON
//GO
///****** Object:  Index [PriceIdId_index]    Script Date: 23/01/2023 14:38:13 ******/
//CREATE NONCLUSTERED INDEX [PriceIdId_index] ON[StripeEvents]
//(

//    [PriceId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
//GO
//SET ANSI_PADDING ON
//GO
///****** Object:  Index [SubscriptionId_index]    Script Date: 23/01/2023 14:38:13 ******/
//CREATE NONCLUSTERED INDEX [SubscriptionId_index] ON[StripeEvents]
//(

//    [SubscriptionId] ASC
//)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
//GO


