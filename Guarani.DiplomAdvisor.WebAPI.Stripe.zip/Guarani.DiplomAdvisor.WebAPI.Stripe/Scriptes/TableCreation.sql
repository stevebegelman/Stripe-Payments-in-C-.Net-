﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [StripeEvents] (
  [Id][int] IDENTITY(1, 1) NOT NULL,
  [EventType] [nvarchar] (32) NOT NULL,
  [Name] [nvarchar] (24) NULL,
	[City][nvarchar] (24) NULL,
	[Email][nvarchar] (32) NULL,
	[KeyId][nvarchar] (12) NULL,
	[CustomerId][nvarchar] (32) NULL,
	[ReceiptEmail][nvarchar] (32) NULL,
	[Description][nvarchar] (64) NULL,
	[Currency][nvarchar] (3) NULL,
	[Amount][bigint] NULL,
	[PaymentId][nvarchar] (32) NULL,
	[PriceId][nvarchar] (32) NULL,
	[SubscriptionId][nvarchar] (32) NULL,
	[EventDate][nvarchar] (18) NULL
) ON[PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [CustomerId_index]    Script Date: 23/01/2023 14:38:12 ******/
CREATE NONCLUSTERED INDEX [CustomerId_index] ON[StripeEvents]
(

    [CustomerId] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [KeyId_index]    Script Date: 23/01/2023 14:38:13 ******/
CREATE NONCLUSTERED INDEX [KeyId_index] ON[StripeEvents]
(

    [KeyId] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [PaymentId_index]    Script Date: 23/01/2023 14:38:13 ******/
CREATE NONCLUSTERED INDEX [PaymentId_index] ON[StripeEvents]
(

    [PaymentId] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [PriceIdId_index]    Script Date: 23/01/2023 14:38:13 ******/
CREATE NONCLUSTERED INDEX [PriceIdId_index] ON[StripeEvents]
(

    [PriceId] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [SubscriptionId_index]    Script Date: 23/01/2023 14:38:13 ******/
CREATE NONCLUSTERED INDEX [SubscriptionId_index] ON[StripeEvents]
(

    [SubscriptionId] ASC
)WITH(PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON[PRIMARY]
GO
