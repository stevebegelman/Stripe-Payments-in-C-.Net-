﻿using System;

// Comment
namespace Stripe_Payments_Web_Api.Models.Stripe
{
    public record DeleteSubscription(
        string SubscriptionId);
}
