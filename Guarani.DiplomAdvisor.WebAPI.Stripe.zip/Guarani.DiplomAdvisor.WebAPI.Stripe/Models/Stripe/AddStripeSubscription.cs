﻿using System;
namespace Stripe_Payments_Web_Api.Models.Stripe
{
    public record AddStripeSubscription(
        string CustomerId,
        string PriceId,
        string ReceiptEmail,
        string Description,
        string DiplomAdvisorCompanyKey);  // Added;
}
